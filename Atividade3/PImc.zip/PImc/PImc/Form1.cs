﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class lblPeso : Form
    {

        double peso, altura, imc;
        public lblPeso()
        {
            InitializeComponent();
        }

        private void lblPeso_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtAltura.Text, out altura)) || altura <= 0)
            {
                MessageBox.Show("Altura Inválida");
                Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            String classificacao, grau;
            classificacao = "";
            grau = "";

            imc = peso / (altura * altura);

            imc = Math.Round(imc, 1);


            if (imc < 18.5)
            {
                classificacao = "Magreza";
            }
            else if (imc <= 24.9)
            {
                classificacao = "Normal";
            }
            else if (imc <= 29.9)
            {
                classificacao = "Sobrepeso";
                grau = "I";
            }
            else if (imc <= 39.9)
            {
                classificacao = "Obesidade";
            }
            else if (imc > 40)
            {
                classificacao = "Obesidade Grave";
            }

            

            txtIMC.Text = $"{imc} {classificacao}";

        
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtPeso.Text, out peso)) || peso <= 0)
            {
                MessageBox.Show("Peso Inválido");
                Focus();
            }
        }
    }
}
