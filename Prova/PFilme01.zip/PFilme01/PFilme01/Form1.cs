﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme01
{
    public partial class btn_Limpar : Form
    {
        public btn_Limpar()
        {
            InitializeComponent();
        }

        private void btn_Executar_Click(object sender, EventArgs e)
        {
            string[,] cinema = new string[3, 2];
            string auxiliar = "";
            double nota;
            double[] soma = new double[2];

            for (int i = 0; i < 3; i++)
            {
                auxiliar = "";
                auxiliar += ($"Pessoa: {i+1}");
                for (int j = 0; j < 2; j++)
                {
                    cinema[i, j] = Interaction.InputBox($"Insira a nota da pessoa {i + 1} para o filme {j + 1}", "Entrada de dados:");

                    if(double.TryParse(cinema[i, j], out nota) && nota <= 10 && nota >= 0)
                    {
                        auxiliar += $" Nota Filme {j + 1}: {nota.ToString("N2")} ";
                        soma[j] += nota;
                    } else
                    {
                        MessageBox.Show("Valor Inválido");
                        j--;
                    }                    
                }
                lstbox_Notas.Items.Add(auxiliar);
            }

            lstbox_Notas.Items.Add("-----------------------------------");
            for (int i = 0; i < 2; i++)
            {
                lstbox_Notas.Items.Add($"Média Filme {i + 1}: {(soma[i] / 3).ToString("N2")}");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            lstbox_Notas.Items.Clear();
        }
    }
}
