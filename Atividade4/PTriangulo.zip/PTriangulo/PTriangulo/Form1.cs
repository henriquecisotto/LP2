namespace PTriangulo
{

    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtValorA.Text, out LadoA)))
            {
                MessageBox.Show("Valor Inv�lido");
                txtValorA.Focus();
            }
            
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtValorB.Text, out LadoB)))
            {
                MessageBox.Show("Valor Inv�lido");
                txtValorB.Focus();
            }
            
        }

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            if (!(double.TryParse(txtValorC.Text, out LadoC)))
            {
                MessageBox.Show("Valor Inv�lido");
                txtValorC.Focus();
            }
            
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(LadoB - LadoC) < LadoA) && (LadoA < LadoB + LadoC) &&
               (Math.Abs(LadoA - LadoC) < LadoB) && (LadoB < LadoA + LadoC) &&
               (Math.Abs(LadoA - LadoB) < LadoC) && (LadoC < LadoA + LadoB))
            {
                if (LadoA == LadoB && LadoA == LadoC)
                {
                    MessageBox.Show("O tri�ngulo � equil�tero");
                }
                else if (LadoA != LadoB && (LadoA != LadoC) && LadoB != LadoC)
                {
                    MessageBox.Show("O tri�ngulo � escaleno");
                }
                else
                {
                    MessageBox.Show("O tri�ngulo � Is�sceles");
                }

            }
            else
            {
                MessageBox.Show("N�o � um tri�ngulo");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
