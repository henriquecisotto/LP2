﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblLadoA = new Label();
            lblLadoB = new Label();
            lblLadoC = new Label();
            txtValorA = new TextBox();
            txtValorC = new TextBox();
            txtValorB = new TextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblLadoA
            // 
            lblLadoA.AutoSize = true;
            lblLadoA.Font = new Font("Segoe UI", 18F);
            lblLadoA.Location = new Point(91, 55);
            lblLadoA.Name = "lblLadoA";
            lblLadoA.Size = new Size(183, 48);
            lblLadoA.TabIndex = 0;
            lblLadoA.Text = "Valor de A";
            // 
            // lblLadoB
            // 
            lblLadoB.AutoSize = true;
            lblLadoB.Font = new Font("Segoe UI", 18F);
            lblLadoB.Location = new Point(91, 142);
            lblLadoB.Name = "lblLadoB";
            lblLadoB.Size = new Size(181, 48);
            lblLadoB.TabIndex = 1;
            lblLadoB.Text = "Valor de B";
            // 
            // lblLadoC
            // 
            lblLadoC.AutoSize = true;
            lblLadoC.Font = new Font("Segoe UI", 18F);
            lblLadoC.Location = new Point(91, 229);
            lblLadoC.Name = "lblLadoC";
            lblLadoC.Size = new Size(182, 48);
            lblLadoC.TabIndex = 2;
            lblLadoC.Text = "Valor de C";
            // 
            // txtValorA
            // 
            txtValorA.Font = new Font("Segoe UI", 18F);
            txtValorA.Location = new Point(298, 52);
            txtValorA.Name = "txtValorA";
            txtValorA.Size = new Size(649, 55);
            txtValorA.TabIndex = 3;
            txtValorA.Validated += txtValorA_Validated;
            // 
            // txtValorC
            // 
            txtValorC.Font = new Font("Segoe UI", 18F);
            txtValorC.Location = new Point(298, 226);
            txtValorC.Name = "txtValorC";
            txtValorC.Size = new Size(649, 55);
            txtValorC.TabIndex = 4;
            txtValorC.Validated += txtValorC_Validated;
            // 
            // txtValorB
            // 
            txtValorB.Font = new Font("Segoe UI", 18F);
            txtValorB.Location = new Point(298, 139);
            txtValorB.Name = "txtValorB";
            txtValorB.Size = new Size(649, 55);
            txtValorB.TabIndex = 5;
            txtValorB.Validated += txtValorB_Validated;
            // 
            // btnCalcular
            // 
            btnCalcular.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCalcular.Location = new Point(91, 332);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(192, 172);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnLimpar.Location = new Point(423, 332);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(192, 172);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSair.Location = new Point(755, 332);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(192, 172);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1653, 569);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtValorB);
            Controls.Add(txtValorC);
            Controls.Add(txtValorA);
            Controls.Add(lblLadoC);
            Controls.Add(lblLadoB);
            Controls.Add(lblLadoA);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblLadoA;
        private Label lblLadoB;
        private Label lblLadoC;
        private TextBox txtValorA;
        private TextBox txtValorC;
        private TextBox txtValorB;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
