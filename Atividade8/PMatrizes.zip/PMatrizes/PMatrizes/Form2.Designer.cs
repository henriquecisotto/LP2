﻿namespace PMatrizes
{
    partial class Exercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_executar = new System.Windows.Forms.Button();
            this.lstbox_Nomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btn_executar
            // 
            this.btn_executar.Location = new System.Drawing.Point(150, 92);
            this.btn_executar.Name = "btn_executar";
            this.btn_executar.Size = new System.Drawing.Size(300, 300);
            this.btn_executar.TabIndex = 0;
            this.btn_executar.Text = "Executar";
            this.btn_executar.UseVisualStyleBackColor = true;
            this.btn_executar.Click += new System.EventHandler(this.btn_executar_Click);
            // 
            // lstbox_Nomes
            // 
            this.lstbox_Nomes.FormattingEnabled = true;
            this.lstbox_Nomes.ItemHeight = 16;
            this.lstbox_Nomes.Location = new System.Drawing.Point(718, 92);
            this.lstbox_Nomes.Name = "lstbox_Nomes";
            this.lstbox_Nomes.Size = new System.Drawing.Size(603, 564);
            this.lstbox_Nomes.TabIndex = 1;
            // 
            // Exercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1440, 765);
            this.Controls.Add(this.lstbox_Nomes);
            this.Controls.Add(this.btn_executar);
            this.Name = "Exercicio4";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_executar;
        private System.Windows.Forms.ListBox lstbox_Nomes;
    }
}