﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_exercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º número", "Entrada de Dados");
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor Inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = String.Join("\n",vetor);

            MessageBox.Show(auxiliar);


        }

        private void btn_exercicio2_Click(object sender, EventArgs e)
        {
            ArrayList Lista = new ArrayList() {"Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" };
            Lista.Remove("Otávio");
            string auxiliar = "";

            foreach(string nome in Lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btn_exercicio3_Click(object sender, EventArgs e)
        {
            double[,] Notas = new double[20, 3];
            string auxiliar = "";
            double media = 0;
            string saida = "";
            for(int i = 0; i < 20; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}", "Entrada de dados");
                    if (!(Double.TryParse(auxiliar, out Notas[i, j])) || Notas[i, j] < 0 || Notas[i, j] > 10)
                    {
                        MessageBox.Show("Dado Inválido");
                        j--;
                    }
                    else
                    {
                        media += Notas[i, j];
                    }
                }
                saida += $"Aluno: {i + 1}\n Média: {(media / 3).ToString("N2")}\n\n";
                media = 0;
                MessageBox.Show(saida);
            }
        }

        private void btn_exercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio4>().Count() < 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                Exercicio4 Exercicio4 = new Exercicio4();
                Exercicio4.Show();
            }
        }

        private void btn_exercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exercicio5>().Count() < 0)
            {
                MessageBox.Show("Form já existe");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                Exercicio5 Exercicio5 = new Exercicio5();
                Exercicio5.Show();
            }

        }
    }
}
